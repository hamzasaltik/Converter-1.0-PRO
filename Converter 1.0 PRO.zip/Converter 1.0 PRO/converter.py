import os
import sys
import shutil
import tempfile
import threading
import subprocess
import zipfile
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import speech_recognition as sr

APP_NAME = "Converter 1.0 PRO"
BG, PANEL = "#F2F8FF", "#FFFFFF"
BLUE, BLUE_DARK = "#2486E8", "#1767BB"
TEXT, MUTED = "#19324D", "#657D96"

AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".wma", ".opus"}
VIDEO_EXT = {".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv", ".flv", ".mpeg", ".mpg", ".m4v"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff", ".gif"}
MEDIA_EXT = AUDIO_EXT | VIDEO_EXT | IMAGE_EXT
# Text and rich-text documents (.txt/.rtf) intentionally are not offered.

def resource_path(*parts):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts)

def ffmpeg_path():
    candidates = [
        resource_path("ffmpeg", "ffmpeg.exe"),
        os.path.join(os.path.dirname(sys.executable), "ffmpeg", "ffmpeg.exe"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "ffmpeg", "ffmpeg.exe"),
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    found = shutil.which("ffmpeg")
    if found:
        return found
    raise FileNotFoundError("FFmpeg bulunamadı. ffmpeg.exe dosyasını ffmpeg klasörüne koy.")

def run_ffmpeg(args):
    cmd = [ffmpeg_path(), "-hide_banner", "-loglevel", "error", "-y"] + args
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, encoding="utf-8", errors="replace",
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if result.returncode:
        raise RuntimeError(result.stderr.strip()[-2500:] or "FFmpeg işlemi başarısız.")

def has_module(name):
    try:
        __import__(name)
        return True
    except ImportError:
        return False

def get_video_duration(path):
    """FFmpeg ile videonun süresini saniye cinsinden döndürür."""
    cmd = [ffmpeg_path(), "-i", path, "-hide_banner"]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, encoding="utf-8", errors="replace",
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    # ffmpeg süreyi stderr'e yazar: Duration: 00:00:30.00
    import re
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.\d+)", result.stderr)
    if not m:
        raise RuntimeError("Video süresi okunamadı.")
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


class ConverterApp:
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.geometry("900x720")
        root.minsize(740, 600)
        root.configure(bg=BG)
        self.busy = False
        self.audio_path = self.image_path = self.video_path = self.transcript_path = None
        self.custom_path = None
        self.frame_video_path = None
        self.extracted_frames = []  # kare sekmesi için çıkarılan görseller

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background="#DCEBFA", foreground=TEXT,
                         padding=(15, 10), font=("Segoe UI", 10, "bold"))
        style.map("TNotebook.Tab", background=[("selected", BLUE)],
                  foreground=[("selected", "white")])
        style.configure("TProgressbar", troughcolor="#DDEBFA", background=BLUE, thickness=7)
        self.build_ui()

    def build_ui(self):
        head = tk.Frame(self.root, bg=BG)
        head.pack(fill="x", padx=22, pady=(14, 8))
        tk.Label(head, text="CONVERTER", font=("Segoe UI", 10, "bold"),
                 fg=BLUE, bg=BG).pack(anchor="w")
        tk.Label(head, text=APP_NAME, font=("Segoe UI", 22, "bold"),
                 fg=TEXT, bg=BG).pack(anchor="w")
        tk.Label(head, text="Ses • Video • Görsel • Kare • Evrensel dönüştürme • Transkript",
                 font=("Segoe UI", 10), fg=MUTED, bg=BG).pack(anchor="w")

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill="both", expand=True, padx=18, pady=6)
        self.tab_av = tk.Frame(self.tabs, bg=BG)
        self.tab_va = tk.Frame(self.tabs, bg=BG)
        self.tab_tr = tk.Frame(self.tabs, bg=BG)
        self.tab_custom = tk.Frame(self.tabs, bg=BG)
        self.tab_frames = tk.Frame(self.tabs, bg=BG)
        self.tabs.add(self.tab_av, text="1. Sesi Videoya")
        self.tabs.add(self.tab_va, text="2. Videoyu Sese")
        self.tabs.add(self.tab_tr, text="3. Transkript")
        self.tabs.add(self.tab_custom, text="4. Özel Dönüştürme")
        self.tabs.add(self.tab_frames, text="5. Kare")
        self.build_audio_video()
        self.build_video_audio()
        self.build_transcript()
        self.build_custom()
        self.build_frames()

        foot = tk.Frame(self.root, bg=BG)
        foot.pack(fill="x", padx=22, pady=(0, 10))
        self.progress = ttk.Progressbar(foot, mode="indeterminate")
        self.progress.pack(fill="x", pady=(0, 6))
        self.status = tk.StringVar(value="Hazır.")
        tk.Label(foot, textvariable=self.status, bg=BG, fg=MUTED,
                 font=("Segoe UI", 9), anchor="w").pack(fill="x")

    def card(self, parent, title, desc):
        frame = tk.Frame(parent, bg=PANEL, highlightbackground="#D7E7F8", highlightthickness=1)
        frame.pack(fill="x", padx=8, pady=8)
        tk.Label(frame, text=title, font=("Segoe UI", 13, "bold"),
                 fg=TEXT, bg=PANEL).pack(anchor="w", padx=16, pady=(13, 3))
        tk.Label(frame, text=desc, font=("Segoe UI", 9), fg=MUTED, bg=PANEL,
                 wraplength=780, justify="left").pack(anchor="w", padx=16, pady=(0, 12))
        return frame

    def button(self, parent, text, command, primary=True):
        return tk.Button(parent, text=text, command=command,
                         bg=BLUE if primary else "#E6F1FF",
                         fg="white" if primary else BLUE_DARK,
                         activebackground=BLUE_DARK, activeforeground="white",
                         relief="flat", bd=0, font=("Segoe UI", 10, "bold"),
                         padx=14, pady=8, cursor="hand2")

    def path_row(self, parent, variable, button_text, command):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", padx=16, pady=(0, 9))
        tk.Label(row, textvariable=variable, bg=PANEL, fg=TEXT,
                 anchor="w", wraplength=570).pack(side="left", fill="x", expand=True)
        self.button(row, button_text, command, False).pack(side="right")
        return row

    def build_audio_video(self):
        c = self.card(self.tab_av, "Sesi MP4 videoya dönüştür",
                      "MP3/WAV gibi bir ses ve arka plan resmi seçerek sesli MP4 oluştur.")
        self.audio_label = tk.StringVar(value="Ses dosyası seçilmedi")
        self.image_label = tk.StringVar(value="Arka plan resmi seçilmedi")
        self.path_row(c, self.audio_label, "Ses seç", self.choose_audio)
        self.path_row(c, self.image_label, "Resim seç", self.choose_image)
        self.button(c, "MP4 oluştur", self.create_video).pack(anchor="e", padx=16, pady=(0, 14))

    def build_video_audio(self):
        c = self.card(self.tab_va, "Videodan ses çıkar",
                      "Videodan MP3 veya WAV ses dosyası oluştur.")
        self.video_label = tk.StringVar(value="Video seçilmedi")
        self.path_row(c, self.video_label, "Video seç", self.choose_video)
        row = tk.Frame(c, bg=PANEL)
        row.pack(anchor="w", padx=16, pady=(0, 8))
        tk.Label(row, text="Çıktı biçimi:", bg=PANEL, fg=TEXT).pack(side="left", padx=(0, 10))
        self.audio_format = tk.StringVar(value="MP3")
        ttk.Combobox(row, textvariable=self.audio_format, values=["MP3", "WAV"],
                     state="readonly", width=10).pack(side="left")
        self.button(c, "Sesi dışa aktar", self.extract_audio).pack(anchor="e", padx=16, pady=(0, 14))

    def build_transcript(self):
        c = self.card(self.tab_tr, "Konuşmayı metne dönüştür",
                      "Ses/video dosyasını seç. Google'ın Türkçe konuşma tanıması internet gerektirir. "
                      "Uzun kayıtlar küçük parçalara ayrılır; anlaşılmayan parçalar yeniden denenir.")
        self.transcript_label = tk.StringVar(value="Dosya seçilmedi")
        self.path_row(c, self.transcript_label, "Dosya seç", self.choose_transcript)
        self.button(c, "Transkripti başlat", self.transcribe).pack(anchor="w", padx=16, pady=(0, 12))
        area = tk.Frame(self.tab_tr, bg=BG)
        area.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.transcript_text = tk.Text(area, wrap="word", font=("Segoe UI", 10),
                                       bg=PANEL, fg=TEXT, relief="flat", padx=10, pady=10)
        scroll = ttk.Scrollbar(area, orient="vertical", command=self.transcript_text.yview)
        self.transcript_text.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.transcript_text.pack(side="left", fill="both", expand=True)
        row = tk.Frame(self.tab_tr, bg=BG)
        row.pack(fill="x", padx=8, pady=(0, 8))
        self.button(row, "Kopyala", self.copy_text).pack(side="left")
        self.button(row, "Metni temizle", lambda: self.transcript_text.delete("1.0", "end"), False).pack(side="left", padx=8)

    def build_custom(self):
        c = self.card(self.tab_custom, "Özel dosya dönüştürücü",
                      "Dosya seçince uzantısı algılanır ve uygun çıktı biçimleri listelenir. "
                      "Ses/video FFmpeg ile, görseller Pillow ile dönüştürülür. "
                      "TXT ve RTF bu sekmede desteklenmez.")
        self.custom_label = tk.StringVar(value="Henüz dosya seçilmedi")
        self.path_row(c, self.custom_label, "Dosya seç", self.choose_custom)
        row = tk.Frame(c, bg=PANEL)
        row.pack(fill="x", padx=16, pady=(0, 10))
        tk.Label(row, text="Dönüştürülecek biçim:", bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=(0, 10))
        self.target_format = tk.StringVar()
        self.format_combo = ttk.Combobox(row, textvariable=self.target_format,
                                         state="readonly", width=18, values=[])
        self.format_combo.pack(side="left")
        self.custom_info = tk.StringVar(value="Önce bir dosya seç.")
        tk.Label(c, textvariable=self.custom_info, bg=PANEL, fg=MUTED,
                 wraplength=760, justify="left").pack(anchor="w", padx=16, pady=(0, 10))
        self.button(c, "Dönüştür ve kaydet", self.convert_custom).pack(anchor="e", padx=16, pady=(0, 14))
        self.card(self.tab_custom, "Kapsam ve sınırlar",
                  "Ses/video: FFmpeg'in desteklediği biçimler. Görsel: PNG, JPG, WebP, BMP, TIFF ve GIF "
                  "(Pillow kurulu olmalı). PDF/Office gibi belgeler yalnızca uygun harici programlar "
                  "kuruluysa dönüştürülebilir; bu sürümde belgeler ve arşivler için evrensel dönüşüm yoktur. "
                  "TXT ve RTF seçilerek dönüştürülmez.")

    def build_frames(self):
        c = self.card(self.tab_frames, "Videodan kare (görsel) çıkar",
                      "Her formatta video seç. Kare sayısını gir (varsayılan 5, maksimum 60). "
                      "Video, seçilen kare sayısına göre eşit parçalara bölünür ve her parçanın "
                      "ortasından bir kare görsel çıkarılır. Örneğin 30 sn'lik video ve 30 kare "
                      "seçilirse her saniyeden bir kare alınır.")
        self.frame_video_label = tk.StringVar(value="Video seçilmedi")
        self.path_row(c, self.frame_video_label, "Video seç", self.choose_frame_video)

        row = tk.Frame(c, bg=PANEL)
        row.pack(fill="x", padx=16, pady=(0, 10))
        tk.Label(row, text="Kare sayısı (max 60):", bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=(0, 10))
        self.frame_count = tk.IntVar(value=5)
        spin = tk.Spinbox(row, from_=1, to=60, textvariable=self.frame_count,
                          width=6, font=("Segoe UI", 10))
        spin.pack(side="left")
        tk.Label(row, text="  (varsayılan 5)", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="left")

        self.frame_info = tk.StringVar(value="Önce bir video seç.")
        tk.Label(c, textvariable=self.frame_info, bg=PANEL, fg=MUTED,
                 wraplength=760, justify="left").pack(anchor="w", padx=16, pady=(0, 10))

        btn_row = tk.Frame(c, bg=PANEL)
        btn_row.pack(fill="x", padx=16, pady=(0, 14))
        self.button(btn_row, "Kareleri çıkar", self.extract_frames).pack(side="left")
        self.button(btn_row, "Hepsini indir", self.download_all_frames, False).pack(side="left", padx=8)

        # Çıkarılan karelerin listelendiği alan
        list_frame = tk.Frame(self.tab_frames, bg=BG)
        list_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.frames_listbox = tk.Listbox(list_frame, font=("Segoe UI", 9),
                                         bg=PANEL, fg=TEXT, relief="flat",
                                         selectmode="extended")
        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.frames_listbox.yview)
        self.frames_listbox.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.frames_listbox.pack(side="left", fill="both", expand=True)

    # ---------------- Seçim işlemleri ----------------
    def choose_audio(self):
        p = filedialog.askopenfilename(filetypes=[("Ses", "*.mp3 *.wav *.m4a *.aac *.ogg *.flac *.wma *.opus"), ("Tüm dosyalar", "*.*")])
        if p:
            self.audio_path = p; self.audio_label.set(os.path.basename(p))

    def choose_image(self):
        p = filedialog.askopenfilename(filetypes=[("Görsel", "*.png *.jpg *.jpeg *.bmp *.webp *.tif *.tiff"), ("Tüm dosyalar", "*.*")])
        if p:
            self.image_path = p; self.image_label.set(os.path.basename(p))

    def choose_video(self):
        p = filedialog.askopenfilename(filetypes=[("Video", "*.mp4 *.mkv *.avi *.mov *.webm *.wmv *.flv"), ("Tüm dosyalar", "*.*")])
        if p:
            self.video_path = p; self.video_label.set(os.path.basename(p))

    def choose_transcript(self):
        p = filedialog.askopenfilename(filetypes=[("Ses ve video", "*.mp3 *.wav *.m4a *.aac *.ogg *.flac *.mp4 *.mkv *.avi *.mov *.webm"), ("Tüm dosyalar", "*.*")])
        if p:
            self.transcript_path = p; self.transcript_label.set(os.path.basename(p))

    def choose_frame_video(self):
        p = filedialog.askopenfilename(
            title="Kare çıkarılacak videoyu seç",
            filetypes=[("Video", "*.mp4 *.mkv *.avi *.mov *.webm *.wmv *.flv *.mpeg *.mpg *.m4v"),
                       ("Tüm dosyalar", "*.*")])
        if p:
            self.frame_video_path = p
            self.frame_video_label.set(os.path.basename(p))
            try:
                dur = get_video_duration(p)
                self.frame_info.set(f"Video süresi: {dur:.2f} saniye. Kare sayısını girip 'Kareleri çıkar' butonuna bas.")
            except Exception as e:
                self.frame_info.set(f"Video seçildi ancak süre okunamadı: {e}")

    # ---------------- İş akışı ----------------
    def start_job(self, title, work, on_success=None):
        if self.busy:
            messagebox.showinfo(APP_NAME, "Bir işlem devam ediyor; bitmesini bekle.")
            return
        self.busy = True
        self.status.set(title)
        self.progress.start(10)
        def worker():
            try:
                result = work()
                self.root.after(0, lambda r=result: self.finish_job(title + " — tamamlandı.", on_success, r))
            except Exception as exc:
                err = str(exc)
                self.root.after(0, lambda e=err: self.fail_job(e))
        threading.Thread(target=worker, daemon=True).start()

    def finish_job(self, text, callback, result):
        self.busy = False
        self.progress.stop()
        self.status.set(text)
        if callback:
            callback(result)
        else:
            messagebox.showinfo(APP_NAME, text)

    def fail_job(self, error):
        self.busy = False
        self.progress.stop()
        self.status.set("İşlem başarısız.")
        messagebox.showerror(APP_NAME, error)

    def create_video(self):
        if not self.audio_path or not os.path.isfile(self.audio_path):
            messagebox.showwarning(APP_NAME, "Önce ses dosyası seç."); return
        if not self.image_path or not os.path.isfile(self.image_path):
            messagebox.showwarning(APP_NAME, "Önce arka plan resmi seç."); return
        out = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4", "*.mp4")])
        if not out: return
        def work():
            run_ffmpeg(["-loop", "1", "-i", self.image_path, "-i", self.audio_path,
                        "-map", "0:v:0", "-map", "1:a:0", "-c:v", "libx264",
                        "-tune", "stillimage", "-vf",
                        "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,format=yuv420p",
                        "-r", "25", "-c:a", "aac", "-b:a", "192k", "-shortest",
                        "-movflags", "+faststart", out])
        self.start_job("MP4 oluşturuluyor", work)

    def extract_audio(self):
        if not self.video_path or not os.path.isfile(self.video_path):
            messagebox.showwarning(APP_NAME, "Önce video seç."); return
        fmt = self.audio_format.get().lower()
        out = filedialog.asksaveasfilename(defaultextension="." + fmt, filetypes=[(fmt.upper(), "*." + fmt)])
        if not out: return
        def work():
            args = ["-i", self.video_path, "-vn"]
            args += ["-c:a", "libmp3lame", "-q:a", "2"] if fmt == "mp3" else ["-c:a", "pcm_s16le", "-ar", "44100"]
            run_ffmpeg(args + [out])
        self.start_job("Ses dışa aktarılıyor", work)

    def transcribe(self):
        if not self.transcript_path or not os.path.isfile(self.transcript_path):
            messagebox.showwarning(APP_NAME, "Önce transkript dosyası seç."); return
        path = self.transcript_path
        def work():
            recognizer = sr.Recognizer()
            recognizer.dynamic_energy_threshold = True
            recognizer.pause_threshold = 0.8
            with tempfile.TemporaryDirectory(prefix="converter_") as temp:
                wav = os.path.join(temp, "normalized.wav")
                run_ffmpeg(["-i", path, "-vn", "-ac", "1", "-ar", "16000",
                            "-af", "highpass=f=100,lowpass=f=7000",
                            "-c:a", "pcm_s16le", wav])
                pattern = os.path.join(temp, "part_%04d.wav")
                run_ffmpeg(["-i", wav, "-f", "segment", "-segment_time", "20",
                            "-reset_timestamps", "1", "-ac", "1", "-ar", "16000",
                            "-c:a", "pcm_s16le", pattern])
                chunks = sorted(os.path.join(temp, f) for f in os.listdir(temp)
                                if f.startswith("part_") and f.endswith(".wav"))
                if not chunks:
                    raise RuntimeError("Ses bulunamadı veya dosya çözümlenemedi.")
                texts = []
                for i, chunk in enumerate(chunks, 1):
                    self.root.after(0, lambda i=i, n=len(chunks):
                                    self.status.set(f"Transkript: bölüm {i}/{n}"))
                    with sr.AudioFile(chunk) as source:
                        audio = recognizer.record(source)
                    result = None
                    last_error = None
                    for attempt in range(2):
                        try:
                            result = recognizer.recognize_google(audio, language="tr-TR")
                            break
                        except sr.UnknownValueError:
                            last_error = "unknown"
                            break
                        except sr.RequestError as exc:
                            last_error = str(exc)
                            if attempt == 0:
                                continue
                    if result:
                        texts.append(result)
                    elif last_error == "unknown":
                        texts.append("[Bu bölüm anlaşılamadı; ses kalitesini kontrol edin.]")
                    else:
                        raise RuntimeError("Google Speech Recognition bağlantı hatası: " + str(last_error))
                return "\n\n".join(texts)
        self.start_job("Transkript hazırlanıyor", work, self.show_transcript)

    def show_transcript(self, text):
        self.transcript_text.delete("1.0", "end")
        self.transcript_text.insert("1.0", text)
        self.tabs.select(self.tab_tr)
        self.status.set("Transkript hazır. Anlaşılmayan bölümler işaretlendi.")

    def copy_text(self):
        text = self.transcript_text.get("1.0", "end-1c")
        if not text.strip():
            messagebox.showwarning(APP_NAME, "Kopyalanacak metin yok."); return
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()
        self.status.set("Metin panoya kopyalandı.")

    # ---------------- Özel dönüştürme ----------------
    def choose_custom(self):
        p = filedialog.askopenfilename(title="Dönüştürülecek dosyayı seç",
                                       filetypes=[("Desteklenen dosyalar", "*.mp3 *.wav *.m4a *.aac *.ogg *.flac *.wma *.opus *.mp4 *.mkv *.avi *.mov *.webm *.wmv *.flv *.mpeg *.mpg *.m4v *.png *.jpg *.jpeg *.bmp *.webp *.tif *.tiff *.gif *.zip *.pdf *.docx"),
                                                  ("Tüm dosyalar (TXT/RTF hariç)", "*.*")])
        if not p: return
        ext = os.path.splitext(p)[1].lower()
        # TXT ve RTF artık desteklenmiyor.
        if ext in {".txt", ".rtf"}:
            messagebox.showwarning(APP_NAME, "TXT ve RTF bu sürümde desteklenmiyor.")
            return
        allowed_extra = {".zip", ".pdf", ".docx"}
        if ext not in MEDIA_EXT and ext not in allowed_extra:
            messagebox.showwarning(APP_NAME,
                "Bu sürümde ses, video, görsel, ZIP, PDF ve DOCX destekleniyor.")
            return
        self.custom_path = p
        self.custom_label.set(os.path.basename(p))
        if ext == ".zip":
            formats = ["EXTRACT"]
            self.custom_info.set("ZIP arşivi algılandı. İçerik, ZIP adıyla bir klasöre çıkarılacak. Başarılı olunca orijinal ZIP silinecek.")
        elif ext == ".pdf":
            formats = ["TXT"]
            self.custom_info.set("PDF içindeki seçilebilir metin TXT'ye çıkarılır. Taranmış görüntüler için OCR gerekir.")
        elif ext == ".docx":
            formats = ["TXT", "PDF"]
            self.custom_info.set("DOCX belgesindeki metin TXT veya PDF olarak kaydedilir.")
        elif ext in IMAGE_EXT:
            formats = [x for x in ["PNG", "JPG", "WEBP", "BMP", "TIFF", "GIF"] if "." + x.lower() != ext]
            self.custom_info.set("Görsel dosyası algılandı. Dönüşüm için Pillow gerekir: py -m pip install Pillow")
        elif ext in AUDIO_EXT:
            formats = [x for x in ["MP3", "WAV", "M4A", "AAC", "OGG", "FLAC", "OPUS"] if "." + x.lower() != ext]
            self.custom_info.set("Ses dosyası algılandı. FFmpeg ile ses biçimleri arasında dönüşüm yapılır.")
        else:
            formats = [x for x in ["MP4", "MKV", "AVI", "MOV", "WEBM", "WMV", "MP3", "WAV"] if "." + x.lower() != ext]
            self.custom_info.set("Video dosyası algılandı. Video biçimine veya ses biçimine dönüştürebilirsin.")
        self.format_combo["values"] = formats
        if formats:
            self.target_format.set(formats[0])

    def convert_custom(self):
        if not self.custom_path or not os.path.isfile(self.custom_path):
            messagebox.showwarning(APP_NAME, "Önce dönüştürülecek dosya seç."); return
        fmt = self.target_format.get().lower()
        if not fmt:
            messagebox.showwarning(APP_NAME, "Çıktı biçimi seç."); return
        src_ext = os.path.splitext(self.custom_path)[1].lower()
        if src_ext == ".zip" and fmt == "extract":
            zip_path = self.custom_path
            folder_name = os.path.splitext(os.path.basename(zip_path))[0]
            destination = os.path.join(os.path.dirname(zip_path), folder_name)
            if os.path.exists(destination):
                messagebox.showerror(APP_NAME, "Aynı adla bir klasör zaten var. Önce klasörü yeniden adlandır veya taşı.")
                return
            if not messagebox.askyesno(APP_NAME, "ZIP içeriği aynı konumda '" + folder_name +
                                       "' klasörüne çıkarılacak. Başarılı olursa ZIP dosyası silinecek. Devam edilsin mi?"):
                return
            def extract_zip():
                os.makedirs(destination)
                try:
                    with zipfile.ZipFile(zip_path, "r") as zf:
                        base = os.path.abspath(destination)
                        for member in zf.infolist():
                            target = os.path.abspath(os.path.join(destination, member.filename))
                            if os.path.commonpath([base, target]) != base:
                                raise RuntimeError("ZIP içinde güvenli olmayan bir dosya yolu bulundu.")
                        zf.extractall(destination)
                    os.remove(zip_path)
                    return destination
                except Exception:
                    shutil.rmtree(destination, ignore_errors=True)
                    raise
            def extracted(path):
                self.custom_path = None
                self.custom_label.set("Çıkarıldı: " + path)
                self.custom_info.set("ZIP başarıyla çıkarıldı ve arşiv silindi.")
                self.format_combo["values"] = []
                self.target_format.set("")
                messagebox.showinfo(APP_NAME, "ZIP çıkarıldı:\n" + path + "\n\nOrijinal ZIP silindi.")
            self.start_job("ZIP çıkarılıyor", extract_zip, extracted)
            return
        out = filedialog.asksaveasfilename(defaultextension="." + fmt,
                                           initialfile=os.path.splitext(os.path.basename(self.custom_path))[0] + "." + fmt,
                                           filetypes=[(fmt.upper(), "*." + fmt)])
        if not out: return
        def work():
            if src_ext in {".pdf", ".docx"}:
                self.convert_document(self.custom_path, src_ext, fmt, out)
            elif src_ext in IMAGE_EXT:
                try:
                    from PIL import Image
                except ImportError:
                    raise RuntimeError("Görsel dönüştürmek için Pillow yükle: py -m pip install Pillow")
                with Image.open(self.custom_path) as img:
                    if fmt in {"jpg", "jpeg"}:
                        if img.mode not in ("RGB", "L"):
                            bg = Image.new("RGB", img.size, "white")
                            if "A" in img.getbands():
                                bg.paste(img, mask=img.getchannel("A"))
                            else:
                                bg.paste(img.convert("RGB"))
                            img = bg
                        else:
                            img = img.convert("RGB")
                    if fmt == "gif" and img.format == "GIF":
                        img.save(out, save_all=True)
                    else:
                        img.save(out, format={"jpg": "JPEG", "tiff": "TIFF"}.get(fmt, fmt.upper()))
            else:
                args = ["-i", self.custom_path]
                if fmt in {"mp3", "wav", "m4a", "aac", "ogg", "flac", "opus"}:
                    args += ["-vn"]
                    if fmt == "mp3": args += ["-c:a", "libmp3lame", "-q:a", "2"]
                    elif fmt == "wav": args += ["-c:a", "pcm_s16le", "-ar", "44100"]
                    elif fmt == "m4a": args += ["-c:a", "aac", "-b:a", "192k"]
                    elif fmt == "aac": args += ["-c:a", "aac", "-f", "adts"]
                    elif fmt == "ogg": args += ["-c:a", "libvorbis", "-q:a", "5"]
                    elif fmt == "flac": args += ["-c:a", "flac"]
                    elif fmt == "opus": args += ["-c:a", "libopus", "-b:a", "128k"]
                else:
                    if fmt in {"mp4", "mov"}:
                        args += ["-c:v", "libx264", "-c:a", "aac", "-pix_fmt", "yuv420p"]
                    elif fmt == "webm":
                        args += ["-c:v", "libvpx-vp9", "-c:a", "libopus"]
                    elif fmt == "avi":
                        args += ["-c:v", "mpeg4", "-c:a", "libmp3lame"]
                    args += ["-f", {"mkv": "matroska"}.get(fmt, fmt)]
                run_ffmpeg(args + [out])
        self.start_job("Dosya dönüştürülüyor", work)

    def convert_document(self, source, source_ext, fmt, output):
        """PDF/DOCX metin dönüşümleri."""
        import html
        import re

        def read_text(path, ext):
            if ext == ".pdf":
                try:
                    from pypdf import PdfReader
                except ImportError:
                    raise RuntimeError("PDF okumak için kur: py -m pip install pypdf")
                reader = PdfReader(path)
                return "\n\n".join(page.extract_text() or "" for page in reader.pages)
            if ext == ".docx":
                try:
                    from docx import Document
                except ImportError:
                    raise RuntimeError("DOCX okumak için kur: py -m pip install python-docx")
                doc = Document(path)
                blocks = [para.text for para in doc.paragraphs]
                for table in doc.tables:
                    for row in table.rows:
                        blocks.append(" | ".join(cell.text for cell in row.cells))
                return "\n".join(blocks)
            return ""

        text = read_text(source, source_ext)
        if fmt == "txt":
            with open(output, "w", encoding="utf-8") as f:
                f.write(text)
        elif fmt == "pdf":
            try:
                from reportlab.lib.pagesizes import A4
                from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
                from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
                from reportlab.lib.enums import TA_LEFT
            except ImportError:
                raise RuntimeError("PDF oluşturmak için kur: py -m pip install reportlab")
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont
            font_name = "Helvetica"
            font_candidates = [
                r"C:\Windows\Fonts\arial.ttf",
                r"C:\Windows\Fonts\segoeui.ttf",
            ]
            for font_path in font_candidates:
                if os.path.isfile(font_path):
                    try:
                        font_name = "ConverterUnicode"
                        pdfmetrics.registerFont(TTFont(font_name, font_path))
                        break
                    except Exception:
                        font_name = "Helvetica"
            doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=48, leftMargin=48,
                                    topMargin=48, bottomMargin=48)
            styles = getSampleStyleSheet()
            body = ParagraphStyle("ConverterBody", parent=styles["BodyText"],
                                  fontName=font_name, fontSize=10, leading=14)
            story = []
            for para in text.splitlines() or [""]:
                safe = html.escape(para) or " "
                story.append(Paragraph(safe, body))
                story.append(Spacer(1, 5))
            doc.build(story)
        else:
            raise RuntimeError("Bu belge dönüşümü desteklenmiyor.")

    # ---------------- Kare çıkarma ----------------
    def extract_frames(self):
        if not self.frame_video_path or not os.path.isfile(self.frame_video_path):
            messagebox.showwarning(APP_NAME, "Önce bir video seç."); return
        try:
            count = int(self.frame_count.get())
        except Exception:
            messagebox.showwarning(APP_NAME, "Kare sayısı geçersiz."); return
        if count < 1:
            messagebox.showwarning(APP_NAME, "Kare sayısı en az 1 olmalı."); return
        if count > 60:
            messagebox.showwarning(APP_NAME, "Kare sayısı en fazla 60 olabilir."); return

        video = self.frame_video_path

        def work():
            # Videonun süresini al
            duration = get_video_duration(video)
            # Her parçanın süresi
            segment_duration = duration / count
            # Geçici klasörde kareleri çıkar
            temp_dir = tempfile.mkdtemp(prefix="converter_frames_")
            frames = []
            for i in range(count):
                # Parçanın ortasındaki zaman (saniye)
                t = (i + 0.5) * segment_duration
                out_path = os.path.join(temp_dir, f"frame_{i+1:03d}.png")
                # -ss ile zamanı ver, tek kare al
                run_ffmpeg(["-ss", str(t), "-i", video, "-frames:v", "1", "-q:v", "2", out_path])
                if os.path.isfile(out_path):
                    frames.append(out_path)
                else:
                    raise RuntimeError(f"Kare {i+1} çıkarılamadı.")
            return frames

        def on_success(frames):
            self.extracted_frames = frames
            self.frames_listbox.delete(0, tk.END)
            for f in frames:
                self.frames_listbox.insert(tk.END, os.path.basename(f))
            self.frame_info.set(f"{len(frames)} kare çıkarıldı. 'Hepsini indir' ile kaydedebilirsin.")
            self.tabs.select(self.tab_frames)
            messagebox.showinfo(APP_NAME, f"{len(frames)} kare başarıyla çıkarıldı.")

        self.start_job("Kareler çıkarılıyor", work, on_success)

    def download_all_frames(self):
        if not self.extracted_frames:
            messagebox.showwarning(APP_NAME, "Önce kareleri çıkar."); return
        folder = filedialog.askdirectory(title="Karelerin kaydedileceği klasörü seç")
        if not folder: return
        try:
            for i, src in enumerate(self.extracted_frames, 1):
                if os.path.isfile(src):
                    dst = os.path.join(folder, os.path.basename(src))
                    shutil.copy2(src, dst)
            messagebox.showinfo(APP_NAME, f"{len(self.extracted_frames)} kare kaydedildi:\n{folder}")
            self.status.set(f"Kareler kaydedildi: {folder}")
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Kareler kaydedilirken hata: {e}")


def main():
    root = tk.Tk()
    ConverterApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()